## Ported Themes

### aalto-dark

![aalto-dark](images/aalto-dark-theme.png)

### aalto-light

![aalto-light](images/aalto-light-theme.png)

### aliceblue

![aliceblue](images/aliceblue-theme.png)

### andreas

![andreas](images/andreas-theme.png)

### arjen

![arjen](images/arjen-theme.png)

### beige-diff

![beige-diff](images/beige-diff-theme.png)

### beige-eshell

![beige-eshell](images/beige-eshell-theme.png)

### bharadwaj-slate

![bharadwaj-slate](images/bharadwaj-slate-theme.png)

### bharadwaj

![bharadwaj](images/bharadwaj-theme.png)

### billw

![billw](images/billw-theme.png)

### black-on-gray

![black-on-gray](images/black-on-gray-theme.png)

### blippblopp

![blippblopp](images/blippblopp-theme.png)

### blue-erc

![blue-erc](images/blue-erc-theme.png)

### blue-eshell

![blue-eshell](images/blue-eshell-theme.png)

### blue-gnus

![blue-gnus](images/blue-gnus-theme.png)

### blue-mood

![blue-mood](images/blue-mood-theme.png)

### blue-sea

![blue-sea](images/blue-sea-theme.png)

### calm-forest

![calm-forest](images/calm-forest-theme.png)

### charcoal-black

![charcoal-black](images/charcoal-black-theme.png)

### clarity

![clarity](images/clarity-theme.png)

### classic

![classic](images/classic-theme.png)

### cobalt

![cobalt](images/cobalt-theme.png)

### comidia

![comidia](images/comidia-theme.png)

### dark-blue

![dark-blue](images/dark-blue-theme.png)

### dark-blue2

![dark-blue2](images/dark-blue2-theme.png)

### dark-erc

![dark-erc](images/dark-erc-theme.png)

### dark-font-lock

![dark-font-lock](images/dark-font-lock-theme.png)

### dark-gnus

![dark-gnus](images/dark-gnus-theme.png)

### dark-green

![dark-green](images/dark-green-theme.png)

### dark-info

![dark-info](images/dark-info-theme.png)

### dark-laptop

![dark-laptop](images/dark-laptop-theme.png)

### deep-blue

![deep-blue](images/deep-blue-theme.png)

### desert

![desert](images/desert-theme.png)

### digital-ofs1

![digital-ofs1](images/digital-ofs1-theme.png)

### emacs-21

![emacs-21](images/emacs-21-theme.png)

### emacs-nw

![emacs-nw](images/emacs-nw-theme.png)

### euphoria

![euphoria](images/euphoria-theme.png)

### feng-shui

![feng-shui](images/feng-shui-theme.png)

### fischmeister

![fischmeister](images/fischmeister-theme.png)

### gnome

![gnome](images/gnome-theme.png)

### gnome2

![gnome2](images/gnome2-theme.png)

### goldenrod

![goldenrod](images/goldenrod-theme.png)

### gray1

![gray1](images/gray1-theme.png)

### gray30

![gray30](images/gray30-theme.png)

### greiner

![greiner](images/greiner-theme.png)

### gtk-ide

![gtk-ide](images/gtk-ide-theme.png)

### high-contrast

![high-contrast](images/high-contrast-theme.png)

### hober

![hober](images/hober-theme.png)

### infodoc

![infodoc](images/infodoc-theme.png)

### jb-simple

![jb-simple](images/jb-simple-theme.png)

### jedit-grey

![jedit-grey](images/jedit-grey-theme.png)

### jonadabian-slate

![jonadabian-slate](images/jonadabian-slate-theme.png)

### jonadabian

![jonadabian](images/jonadabian-theme.png)

### jsc-dark

![jsc-dark](images/jsc-dark-theme.png)

### jsc-light

![jsc-light](images/jsc-light-theme.png)

### jsc-light2

![jsc-light2](images/jsc-light2-theme.png)

### katester

![katester](images/katester-theme.png)

### kingsajz

![kingsajz](images/kingsajz-theme.png)

### late-night

![late-night](images/late-night-theme.png)

### lawrence

![lawrence](images/lawrence-theme.png)

### ld-dark

![ld-dark](images/ld-dark-theme.png)

### lethe

![lethe](images/lethe-theme.png)

### marine

![marine](images/marine-theme.png)

### marquardt

![marquardt](images/marquardt-theme.png)

### matrix

![matrix](images/matrix-theme.png)

### midnight

![midnight](images/midnight-theme.png)

### mistyday

![mistyday](images/mistyday-theme.png)

### montz

![montz](images/montz-theme.png)

### oswald

![oswald](images/oswald-theme.png)

### parus

![parus](images/parus-theme.png)

### pierson

![pierson](images/pierson-theme.png)

### pok-wob

![pok-wob](images/pok-wob-theme.png)

### pok-wog

![pok-wog](images/pok-wog-theme.png)

### ramangalahy

![ramangalahy](images/ramangalahy-theme.png)

### raspopovic

![raspopovic](images/raspopovic-theme.png)

### renegade

![renegade](images/renegade-theme.png)

### resolve

![resolve](images/resolve-theme.png)

### retro-green

![retro-green](images/retro-green-theme.png)

### retro-orange

![retro-orange](images/retro-orange-theme.png)

### robin-hood

![robin-hood](images/robin-hood-theme.png)

### rotor

![rotor](images/rotor-theme.png)

### ryerson

![ryerson](images/ryerson-theme.png)

### salmon-diff

![salmon-diff](images/salmon-diff-theme.png)

### salmon-font-lock

![salmon-font-lock](images/salmon-font-lock-theme.png)

### scintilla

![scintilla](images/scintilla-theme.png)

### shaman

![shaman](images/shaman-theme.png)

### simple-1

![simple-1](images/simple-1-theme.png)

### sitaramv-nt

![sitaramv-nt](images/sitaramv-nt-theme.png)

### sitaramv-solaris

![sitaramv-solaris](images/sitaramv-solaris-theme.png)

### snow

![snow](images/snow-theme.png)

### snowish

![snowish](images/snowish-theme.png)

### standard-ediff

![standard-ediff](images/standard-ediff-theme.png)

### standard

![standard](images/standard-theme.png)

### subtle-blue

![subtle-blue](images/subtle-blue-theme.png)

### subtle-hacker

![subtle-hacker](images/subtle-hacker-theme.png)

### taming-mr-arneson

![taming-mr-arneson](images/taming-mr-arneson-theme.png)

### taylor

![taylor](images/taylor-theme.png)

### tty-dark

![tty-dark](images/tty-dark-theme.png)

### vim-colors

![vim-colors](images/vim-colors-theme.png)

### whateveryouwant

![whateveryouwant](images/whateveryouwant-theme.png)

### wheat

![wheat](images/wheat-theme.png)

### word-perfect

![word-perfect](images/word-perfect-theme.png)

### xemacs

![xemacs](images/xemacs-theme.png)

### xp

![xp](images/xp-theme.png)

## 3rd Party Theme

### julie

![julie](images/julie-theme.png)

### subdued

![subdued](images/subdued-theme.png)

### railscast

![railscast](images/railscast-theme.png)
